Deploy to Vercel (step-by-step)
1. Create a GitHub repository and push this project.
2. Go to https://vercel.com/new and import the repo.
3. Vercel will detect Next.js. Click Deploy.
4. After deploy, go to Project Settings -> Domains -> Add Domain `petak.desa.id`.
5. Follow DNS instructions: add CNAME/ALIAS records as shown by Vercel.

If your domain is managed by a government DNS team, share the Vercel verification records with them.
