export default function Lembaga(){
  return (
    <section>
      <h2 style={{color:'var(--green)'}}>Lembaga Desa</h2>
      <div className="card" style={{marginTop:12}}>
        <p>Informasi tentang BPD, LPM, PKK, Karang Taruna dan lembaga lainnya.</p>
      </div>
    </section>
  )
}
