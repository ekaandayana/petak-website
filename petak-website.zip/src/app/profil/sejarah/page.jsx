export default function Sejarah(){
  return (
    <section>
      <h2 style={{color:'var(--green)'}}>Sejarah Desa Petak</h2>
      <div className="card" style={{marginTop:12}}>
        <p>Sejarah singkat desa — (isi bisa diedit oleh admin).</p>
      </div>
    </section>
  )
}
