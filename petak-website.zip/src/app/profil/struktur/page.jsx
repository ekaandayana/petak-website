export default function Struktur(){
  return (
    <section>
      <h2 style={{color:'var(--green)'}}>Struktur Pemerintahan Desa</h2>
      <div className="card" style={{marginTop:12}}>
        <p>Daftar perangkat desa, kontak, dan struktur organisasi.</p>
      </div>
    </section>
  )
}
