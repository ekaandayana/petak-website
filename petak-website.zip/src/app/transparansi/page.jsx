export default function Transparansi(){
  return (
    <section>
      <h2 style={{color:'var(--green)'}}>Transparansi & APBDes</h2>
      <div className="card" style={{marginTop:12}}>
        <h4>APBDes 2025 (Ringkasan)</h4>
        <ul>
          <li>Pendapatan: Rp X.xxx.xxx</li>
          <li>Belanja: Rp X.xxx.xxx</li>
          <li>Transfer: Rp X.xxx.xxx</li>
        </ul>
        <p>Unduh laporan lengkap tersedia untuk warga.</p>
      </div>
    </section>
  )
}
